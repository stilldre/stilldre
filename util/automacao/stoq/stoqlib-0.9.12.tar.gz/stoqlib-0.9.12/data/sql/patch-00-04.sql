-- #3288: Remove TillEntry.is_initial_cash_amount
ALTER TABLE till_entry DROP COLUMN is_initial_cash_amount;
