-- 4038: Remover parametro 'Habilitar produtos compostos'

-- This file avoid update erros, since we removed a system parameter
-- and we need to bump the database version to register this change.
