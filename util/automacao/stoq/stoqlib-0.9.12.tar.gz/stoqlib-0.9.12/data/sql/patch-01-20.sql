ALTER TABLE payment ADD COLUMN penalty numeric(10, 2);
