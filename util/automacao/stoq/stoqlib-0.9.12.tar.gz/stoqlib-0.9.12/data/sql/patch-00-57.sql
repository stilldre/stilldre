DROP TABLE inheritable_model;
DROP TABLE inheritable_model_adapter;
