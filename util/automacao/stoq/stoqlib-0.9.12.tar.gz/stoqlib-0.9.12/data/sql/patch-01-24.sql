-- 4004: Definição da unidade padrão nos parâmetros do sistema

-- This file avoid update erros, since we added a system parameter
-- and we need to bump the database version to register this change.
