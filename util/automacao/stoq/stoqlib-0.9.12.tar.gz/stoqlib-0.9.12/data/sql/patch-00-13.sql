-- #2978: Empty till objects are sometimes created
ALTER TABLE sale DROP COLUMN till_id;
