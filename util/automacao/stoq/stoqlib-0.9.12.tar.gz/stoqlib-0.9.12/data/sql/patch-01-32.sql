-- Add city_registry column in person_adapt_to_company table.


ALTER TABLE person_adapt_to_company ADD COLUMN city_registry text;
