-- #3800: Remove Payment Operation
DROP TABLE po_adapt_to_payment_devolution;
DROP TABLE po_adapt_to_payment_deposit;
DROP TABLE payment_operation;
