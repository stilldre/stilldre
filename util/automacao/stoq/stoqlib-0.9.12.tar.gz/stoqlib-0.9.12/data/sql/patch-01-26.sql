-- 3468: As funções "gravar" e "limpar" cookies devem ser habilitadas nos parâmetros do sistema.

-- This file avoid update erros, since we added a system parameter
-- and we need to bump the database version to register this change.
